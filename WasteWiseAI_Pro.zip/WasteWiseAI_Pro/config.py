# ==============================
# WasteWiseAI Pro Configuration
# ==============================

# Project Information
APP_NAME = "WasteWiseAI Pro"
APP_ICON = "♻️"
VERSION = "1.0"

# Page Configuration
PAGE_TITLE = "WasteWiseAI Pro"
PAGE_ICON = "♻️"
LAYOUT = "wide"

# Theme Colors
PRIMARY_COLOR = "#2E8B57"      # Sea Green
SECONDARY_COLOR = "#F5F7FA"    # Light Gray
SIDEBAR_COLOR = "#1F2937"      # Dark Gray
CARD_COLOR = "#FFFFFF"         # White
TEXT_COLOR = "#111827"         # Almost Black

# Dashboard Defaults
TOTAL_BINS = 120
ACTIVE_TRUCKS = 8
PENDING_COLLECTIONS = 24
RECYCLED_WASTE = "2.4 Tons"

# Status Colors
STATUS_LOW = "#22C55E"
STATUS_MEDIUM = "#FACC15"
STATUS_HIGH = "#EF4444"