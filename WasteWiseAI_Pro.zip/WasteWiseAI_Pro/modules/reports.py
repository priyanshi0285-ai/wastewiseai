import streamlit as st
import pandas as pd
import plotly.express as px


def reports_page():

    # ---------------- CSS ----------------

    st.markdown("""
    <style>

    .page-title {
        font-size: 42px;
        font-weight: 800;
        color: #111827;
        margin-bottom: 5px;
    }

    .page-subtitle {
        font-size: 18px;
        color: #64748B;
        margin-bottom: 30px;
    }

    .card {
        background: white;
        padding: 20px;
        border-radius: 18px;
        text-align: center;
        box-shadow: 0px 4px 15px rgba(0,0,0,0.10);
        min-height: 145px;
    }

    .card-icon {
        font-size: 28px;
        margin-bottom: 5px;
    }

    .card-title {
        font-size: 16px;
        font-weight: 600;
        color: #334155;
    }

    .card-value {
        font-size: 30px;
        font-weight: 800;
        color: #111827;
        margin: 5px 0;
    }

    .card-sub {
        font-size: 13px;
        color: #64748B;
    }

    </style>
    """, unsafe_allow_html=True)


    # ---------------- Header ----------------

    st.markdown(
        "<div class='page-title'>📊 Waste Management Reports</div>",
        unsafe_allow_html=True
    )

    st.markdown(
        "<div class='page-subtitle'>Summary reports generated from waste collection and AI predictions.</div>",
        unsafe_allow_html=True
    )


    # ---------------- Report Data ----------------

    report_data = pd.DataFrame({

        "Waste Type": [
            "Plastic",
            "Paper",
            "Metal",
            "Glass",
            "Organic"
        ],

        "Collected (kg)": [
            120,
            95,
            60,
            45,
            150
        ],

        "Recycled (kg)": [
            100,
            82,
            55,
            40,
            120
        ]
    })


    # ---------------- Calculations ----------------

    total_collected = report_data["Collected (kg)"].sum()

    total_recycled = report_data["Recycled (kg)"].sum()

    recycling_rate = round(
        (total_recycled / total_collected) * 100,
        1
    )

    remaining_waste = total_collected - total_recycled


    # ---------------- KPI Cards ----------------

    col1, col2, col3, col4 = st.columns(4)


    with col1:

        st.markdown(
            f"""
            <div class="card">
                <div class="card-icon">🗑️</div>
                <div class="card-title">Total Waste</div>
                <div class="card-value">{total_collected} kg</div>
                <div class="card-sub">Collected waste</div>
            </div>
            """,
            unsafe_allow_html=True
        )


    with col2:

        st.markdown(
            f"""
            <div class="card">
                <div class="card-icon">♻️</div>
                <div class="card-title">Total Recycled</div>
                <div class="card-value">{total_recycled} kg</div>
                <div class="card-sub">Recovered waste</div>
            </div>
            """,
            unsafe_allow_html=True
        )


    with col3:

        st.markdown(
            f"""
            <div class="card">
                <div class="card-icon">📈</div>
                <div class="card-title">Recycling Rate</div>
                <div class="card-value">{recycling_rate}%</div>
                <div class="card-sub">Overall efficiency</div>
            </div>
            """,
            unsafe_allow_html=True
        )


    with col4:

        st.markdown(
            f"""
            <div class="card">
                <div class="card-icon">🚮</div>
                <div class="card-title">Remaining Waste</div>
                <div class="card-value">{remaining_waste} kg</div>
                <div class="card-sub">Not yet recycled</div>
            </div>
            """,
            unsafe_allow_html=True
        )


    st.markdown("<br>", unsafe_allow_html=True)


    # ---------------- Waste Report ----------------

    st.subheader("📋 Waste Collection Report")

    st.dataframe(
        report_data,
        use_container_width=True,
        hide_index=True
    )


    # ---------------- Charts ----------------

    col1, col2 = st.columns(2)


    with col1:

        st.subheader("🗑️ Collected Waste")

        collected_chart = px.bar(
            report_data,
            x="Waste Type",
            y="Collected (kg)",
            title="Waste Collected by Category"
        )

        collected_chart.update_layout(
            plot_bgcolor="white",
            paper_bgcolor="white",
            margin=dict(l=20, r=20, t=50, b=20)
        )

        st.plotly_chart(
            collected_chart,
            use_container_width=True
        )


    with col2:

        st.subheader("♻️ Recycled Waste")

        recycled_chart = px.bar(
            report_data,
            x="Waste Type",
            y="Recycled (kg)",
            title="Waste Recycled by Category"
        )

        recycled_chart.update_layout(
            plot_bgcolor="white",
            paper_bgcolor="white",
            margin=dict(l=20, r=20, t=50, b=20)
        )

        st.plotly_chart(
            recycled_chart,
            use_container_width=True
        )


    # ---------------- Recycling Comparison ----------------

    st.subheader("📊 Collection vs Recycling")

    comparison_data = report_data.melt(
        id_vars="Waste Type",
        value_vars=[
            "Collected (kg)",
            "Recycled (kg)"
        ],
        var_name="Type",
        value_name="Weight (kg)"
    )

    comparison_chart = px.bar(
        comparison_data,
        x="Waste Type",
        y="Weight (kg)",
        color="Type",
        barmode="group",
        title="Collected vs Recycled Waste"
    )

    comparison_chart.update_layout(
        plot_bgcolor="white",
        paper_bgcolor="white",
        margin=dict(l=20, r=20, t=50, b=20)
    )

    st.plotly_chart(
        comparison_chart,
        use_container_width=True
    )


    # ---------------- Report Status ----------------

    st.success(
        "📄 Report generated successfully."
    )