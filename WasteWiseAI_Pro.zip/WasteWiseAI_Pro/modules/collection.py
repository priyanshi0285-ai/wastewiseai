import streamlit as st
import pandas as pd


def collection_page():

    # ---------------- CSS ----------------

    st.markdown("""
    <style>

    .page-title {
        font-size: 42px;
        font-weight: 800;
        color: #111827;
        margin-bottom: 5px;
    }

    .page-subtitle {
        font-size: 18px;
        color: #64748B;
        margin-bottom: 30px;
    }

    .card {
        background: white;
        padding: 20px;
        border-radius: 18px;
        text-align: center;
        box-shadow: 0px 4px 15px rgba(0,0,0,0.10);
        min-height: 150px;
    }

    .card-icon {
        font-size: 28px;
        margin-bottom: 5px;
    }

    .card-title {
        font-size: 16px;
        font-weight: 600;
        color: #334155;
    }

    .card-value {
        font-size: 32px;
        font-weight: 800;
        color: #111827;
        margin: 5px 0;
    }

    .card-sub {
        font-size: 13px;
        color: #64748B;
    }

    .status-card {
        padding: 18px;
        border-radius: 14px;
        font-size: 16px;
        font-weight: 500;
        background: #E8F8EE;
        color: #15803D;
    }

    </style>
    """, unsafe_allow_html=True)


    # ---------------- Page Header ----------------

    st.markdown(
        "<div class='page-title'>🚛 Waste Collection Management</div>",
        unsafe_allow_html=True
    )

    st.markdown(
        "<div class='page-subtitle'>Manage waste pickup schedules and collection priorities in real time.</div>",
        unsafe_allow_html=True
    )


    # ---------------- Bin Data ----------------

    bins = pd.DataFrame({
        "Bin_ID": [
            "BIN-001",
            "BIN-002",
            "BIN-003",
            "BIN-004",
            "BIN-005",
            "BIN-006"
        ],

        "Location": [
            "Main Gate",
            "Cafeteria",
            "Library",
            "Hostel",
            "Parking",
            "Admin Block"
        ],

        "Fill_Level": [
            95,
            72,
            35,
            88,
            18,
            60
        ]
    })


    # ---------------- Calculations ----------------

    total_pickups = len(bins)

    urgent_collection = len(
        bins[bins["Fill_Level"] >= 80]
    )

    upcoming_collection = len(
        bins[
            (bins["Fill_Level"] >= 50)
            &
            (bins["Fill_Level"] < 80)
        ]
    )

    average_fill = bins["Fill_Level"].mean()


    # ---------------- KPI Cards ----------------
    # ---------------- KPI Cards ----------------

    c1, c2, c3, c4 = st.columns(4)

    with c1:
        st.markdown(
            """
            <div class="card">
                <div class="card-icon">🚛</div>
                <div class="card-title">Total Pickups</div>
                <div class="card-value">6</div>
                <div class="card-sub">Bins requiring collection</div>
            </div>
            """,
           unsafe_allow_html=True)

    with c2:
        st.markdown(
            """
            <div class="card">
                <div class="card-icon">🔴</div>
                <div class="card-title">Urgent Collection</div>
                <div class="card-value">2</div>
                <div class="card-sub">Full bins</div>
            </div>
            """,
            unsafe_allow_html=True
        )

    with c3:
        st.markdown(
            """
            <div class="card">
                <div class="card-icon">🟡</div>
                <div class="card-title">Upcoming Collection</div>
                <div class="card-value">2</div>
                <div class="card-sub">Warning bins</div>
            </div>
            """,
            unsafe_allow_html=True
        )

    with c4:
        st.markdown(
            """
            <div class="card">
                <div class="card-icon">📊</div>
                <div class="card-title">Average Fill</div>
                <div class="card-value">61.3%</div>
                <div class="card-sub">Across all bins</div>
            </div>
            """,
            unsafe_allow_html=True)
    


    # ---------------- Collection Overview ----------------

    st.subheader("📋 Collection Overview")


    urgent = bins[bins["Fill_Level"] >= 80]

    if len(urgent) > 0:

        for _, row in urgent.iterrows():

            st.error(
                f"🔴 {row['Bin_ID']} — {row['Location']} — "
                f"{row['Fill_Level']}% filled — Pickup Required."
            )


    # ---------------- Upcoming Collection ----------------

    st.subheader("🟡 Upcoming Collection")


    upcoming = bins[
        (bins["Fill_Level"] >= 50)
        &
        (bins["Fill_Level"] < 80)
    ]


    if len(upcoming) > 0:

        for _, row in upcoming.iterrows():

            st.info(
                f"🟡 {row['Bin_ID']} — {row['Location']} — "
                f"{row['Fill_Level']}% filled — Monitor for upcoming collection."
            )

    else:

        st.success("No upcoming collections.")


    # ---------------- Collection Schedule ----------------

    st.subheader("📋 Collection Schedule")


    schedule = bins.copy()


    def get_priority(fill):

        if fill >= 80:
            return "🔴 High"

        elif fill >= 50:
            return "🟡 Medium"

        else:
            return "🟢 Low"


    def get_status(fill):

        if fill >= 80:
            return "Pickup Required"

        elif fill >= 50:
            return "Monitor"

        else:
            return "Not Required"


    schedule["Priority"] = schedule["Fill_Level"].apply(
        get_priority
    )

    schedule["Collection Status"] = schedule["Fill_Level"].apply(
        get_status
    )

    schedule["Fill_Level"] = (
        schedule["Fill_Level"].astype(str) + "%"
    )


    st.dataframe(
        schedule,
        use_container_width=True,
        hide_index=True
    )


    # ---------------- System Status ----------------

    st.subheader("⚙️ Collection System Status")


    s1, s2, s3 = st.columns(3)


    with s1:

        st.markdown(
            """
            <div class="status-card">
            ✅ Collection System Active
            </div>
            """,
            unsafe_allow_html=True
        )


    with s2:

        st.markdown(
            """
            <div class="status-card">
            ✅ Smart Bins Connected
            </div>
            """,
            unsafe_allow_html=True
        )


    with s3:

        st.markdown(
            """
            <div class="status-card">
            ✅ Monitoring Active
            </div>
            """,
            unsafe_allow_html=True
        )