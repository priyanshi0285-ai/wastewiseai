import streamlit as st
import pandas as pd
import os


def smart_bins_page():

    # ---------------- CSS ----------------

    st.markdown("""
    <style>

    .main {
        background: #F5F7FA;
    }

    .title {
        font-size: 40px;
        font-weight: 800;
        color: #111827;
    }

    .subtitle {
        font-size: 17px;
        color: #64748B;
        margin-bottom: 25px;
    }

    .bin-box {
        background: white;
        padding: 20px;
        border-radius: 18px;
        box-shadow: 0px 4px 12px rgba(0,0,0,0.10);
        margin-bottom: 20px;
    }

    .bin-name {
        font-size: 21px;
        font-weight: 700;
        color: #111827;
    }

    .bin-location {
        color: #64748B;
        font-size: 14px;
        margin-bottom: 12px;
    }

    .status-normal {
        color: #16A34A;
        font-weight: 700;
    }

    .status-warning {
        color: #D97706;
        font-weight: 700;
    }

    .status-full {
        color: #DC2626;
        font-weight: 700;
    }

    </style>
    """, unsafe_allow_html=True)


    # ---------------- Load Sensor Data ----------------

    sensor_file = "database/sensor_data.csv"


    if os.path.exists(sensor_file):

        bin_data = pd.read_csv(sensor_file)

    else:

        bin_data = pd.DataFrame({
            "Bin_ID": ["BIN-001"],
            "Location": ["Main Gate"],
            "Fill_Level": [0],
            "Status": ["Normal"]
        })


    # ---------------- Clean Data ----------------

    bin_data["Fill_Level"] = pd.to_numeric(
        bin_data["Fill_Level"],
        errors="coerce"
    ).fillna(0)


    bin_data["Status"] = bin_data["Status"].astype(str)


    # ---------------- Calculations ----------------

    total_bins = len(bin_data)

    full_bins = len(
        bin_data[
            bin_data["Fill_Level"] >= 80
        ]
    )

    warning_bins = len(
        bin_data[
            (bin_data["Fill_Level"] >= 50) &
            (bin_data["Fill_Level"] < 80)
        ]
    )

    normal_bins = len(
        bin_data[
            bin_data["Fill_Level"] < 50
        ]
    )

    avg_fill = round(
        bin_data["Fill_Level"].mean(),
        1
    )


    # ---------------- Header ----------------

    st.markdown(
        "<div class='title'>🗑️ Smart Bin Monitoring</div>",
        unsafe_allow_html=True
    )

    st.markdown(
        "<div class='subtitle'>Monitor smart bins, fill levels and collection priority in real time.</div>",
        unsafe_allow_html=True
    )


    # ---------------- KPI Cards ----------------

    c1, c2, c3, c4 = st.columns(4)


    with c1:

        st.metric(
            "🗑️ Total Bins",
            total_bins,
            "Installed Bins"
        )


    with c2:

        st.metric(
            "🔴 Full Bins",
            full_bins,
            "Pickup Required"
        )


    with c3:

        st.metric(
            "🟡 Warning",
            warning_bins,
            "Monitor Closely"
        )


    with c4:

        st.metric(
            "📊 Average Fill",
            f"{avg_fill}%",
            "Across All Bins"
        )


    st.write("")


    # ---------------- Status Overview ----------------

    st.subheader("📊 Bin Status Overview")


    s1, s2, s3 = st.columns(3)


    with s1:

        st.success(
            f"🟢 Normal Bins\n\n{normal_bins}"
        )


    with s2:

        st.warning(
            f"🟡 Warning Bins\n\n{warning_bins}"
        )


    with s3:

        st.error(
            f"🔴 Full Bins\n\n{full_bins}"
        )


    st.write("")


    # ---------------- Individual Bin Monitoring ----------------

    st.subheader("🗑️ Individual Bin Monitoring")


    for index, row in bin_data.iterrows():

        bin_id = row["Bin_ID"]
        location = row["Location"]
        fill = float(row["Fill_Level"])


        if fill >= 80:

            status_text = "🔴 Full"
            priority = "High Priority"
            status_class = "status-full"

        elif fill >= 50:

            status_text = "🟡 Warning"
            priority = "Medium Priority"
            status_class = "status-warning"

        else:

            status_text = "🟢 Normal"
            priority = "Low Priority"
            status_class = "status-normal"


        left, right = st.columns([2, 1])


        with left:

            st.markdown(
                f"""
                <div class="bin-box">

                <div class="bin-name">
                🗑️ {bin_id}
                </div>

                <div class="bin-location">
                📍 {location}
                </div>

                </div>
                """,
                unsafe_allow_html=True
            )


        with right:

            st.markdown(
                f"""
                <div class="bin-box">

                <div class="{status_class}">
                {status_text}
                </div>

                <div>
                <b>{fill:.0f}%</b> Fill Level
                </div>

                </div>
                """,
                unsafe_allow_html=True
            )


        st.progress(
            min(fill / 100, 1.0)
        )


        if fill >= 80:

            st.error(
                f"🚛 Collection required for {bin_id} — {priority}"
            )

        elif fill >= 50:

            st.warning(
                f"⚠️ Monitor {bin_id} — {priority}"
            )

        else:

            st.success(
                f"✅ {bin_id} operating normally — {priority}"
            )


        st.write("")


    # ---------------- Detailed Table ----------------

    st.subheader("📋 Bin Details")


    display_data = bin_data.copy()


    display_data["Fill_Level"] = (
        display_data["Fill_Level"].round(0).astype(int).astype(str)
        + "%"
    )


    st.dataframe(
        display_data,
        use_container_width=True,
        hide_index=True
    )