import streamlit as st


def profile_page():

    # ---------------- CSS ----------------

    st.markdown("""
    <style>

    .auth-title {
        font-size: 42px;
        font-weight: 800;
        color: #111827;
        margin-bottom: 5px;
    }

    .auth-subtitle {
        font-size: 18px;
        color: #64748B;
        margin-bottom: 30px;
    }

    .auth-heading {
        font-size: 25px;
        font-weight: 700;
        color: #111827;
        text-align: center;
        margin-top: 15px;
        margin-bottom: 5px;
    }

    .auth-description {
        font-size: 14px;
        color: #64748B;
        text-align: center;
        margin-bottom: 25px;
    }

    </style>
    """, unsafe_allow_html=True)


    # ---------------- Header ----------------

    st.markdown(
        "<div class='auth-title'>🔐 Login / Reg</div>",
        unsafe_allow_html=True
    )

    st.markdown(
        "<div class='auth-subtitle'>Access your WasteWiseAI account</div>",
        unsafe_allow_html=True
    )


    # ---------------- Center Layout ----------------

    left, center, right = st.columns([1.2, 2, 1.2])

    with center:

        # ---------------- Tabs ----------------

        tab1, tab2 = st.tabs([
            "🔐 Login",
            "📝 Register"
        ])


        # ---------------- LOGIN ----------------

        with tab1:

            st.markdown(
                "<div class='auth-heading'>Welcome Back</div>",
                unsafe_allow_html=True
            )

            st.markdown(
                "<div class='auth-description'>Sign in to your WasteWiseAI account</div>",
                unsafe_allow_html=True
            )

            username = st.text_input(
                "Username",
                key="login_user"
            )

            password = st.text_input(
                "Password",
                type="password",
                key="login_pass"
            )

            st.checkbox(
                "Remember Me",
                key="remember_me"
            )

            if st.button(
                "Login",
                use_container_width=True
            ):

                if username and password:

                    st.success(
                        f"Welcome, {username}! 🎉"
                    )

                else:

                    st.error(
                        "Please enter your username and password."
                    )


        # ---------------- REGISTER ----------------

        with tab2:

            st.markdown(
                "<div class='auth-heading'>Create a New Account</div>",
                unsafe_allow_html=True
            )

            st.markdown(
                "<div class='auth-description'>Join WasteWiseAI and manage smart waste collection</div>",
                unsafe_allow_html=True
            )

            new_name = st.text_input(
                "Full Name",
                key="register_name"
            )

            new_email = st.text_input(
                "Email",
                key="register_email"
            )

            new_user = st.text_input(
                "Username",
                key="register_user"
            )

            new_pass = st.text_input(
                "Password",
                type="password",
                key="register_pass"
            )

            confirm_pass = st.text_input(
                "Confirm Password",
                type="password",
                key="register_confirm"
            )

            if st.button(
                "Create Account",
                use_container_width=True
            ):

                if not all([
                    new_name,
                    new_email,
                    new_user,
                    new_pass,
                    confirm_pass
                ]):

                    st.warning(
                        "Please fill in all fields."
                    )

                elif new_pass != confirm_pass:

                    st.error(
                        "Passwords do not match."
                    )

                else:

                    st.success(
                        "🎉 Account created successfully! (Demo Mode)"
                    )