import streamlit as st
import pandas as pd
import pydeck as pdk

def route_page():

    # ---------------- CSS ----------------

    st.markdown("""
    <style>

    .page-title {
        font-size: 42px;
        font-weight: 800;
        color: #111827;
        margin-bottom: 5px;
    }

    .page-subtitle {
        font-size: 18px;
        color: #64748B;
        margin-bottom: 30px;
    }

    .card {
        background: white;
        padding: 20px;
        border-radius: 18px;
        text-align: center;
        box-shadow: 0px 4px 15px rgba(0,0,0,0.10);
        min-height: 145px;
    }

    .card-icon {
        font-size: 28px;
        margin-bottom: 5px;
    }

    .card-title {
        font-size: 16px;
        font-weight: 600;
        color: #334155;
    }

    .card-value {
        font-size: 32px;
        font-weight: 800;
        color: #111827;
        margin: 5px 0;
    }

    .card-sub {
        font-size: 13px;
        color: #64748B;
    }

    .route-box {
        background: #EFF6FF;
        padding: 16px;
        border-radius: 12px;
        margin-bottom: 12px;
        color: #075985;
        font-size: 16px;
    }

    </style>
    """, unsafe_allow_html=True)


    # ---------------- Header ----------------

    st.markdown(
        "<div class='page-title'>🗺️ AI Collection Route</div>",
        unsafe_allow_html=True
    )

    st.markdown(
        "<div class='page-subtitle'>Optimized waste collection route based on bin priority and location.</div>",
        unsafe_allow_html=True
    )


    # ---------------- Route Data ----------------

    route = pd.DataFrame({

        "Stop": [
            1,
            2,
            3,
            4
        ],

        "Bin_ID": [
            "BIN-001",
            "BIN-004",
            "BIN-002",
            "BIN-006"
        ],

        "Location": [
            "Main Gate",
            "Hostel",
            "Cafeteria",
            "Admin Block"
        ],

        "Priority": [
            "High",
            "High",
            "Medium",
            "Medium"
        ],

        "Distance_km": [
            0,
            1.8,
            3.4,
            5.2
        ]
    })


    # ---------------- Demo Bin Coordinates ----------------

    # Demo coordinates for now.
    # Replace these with real coordinates later.

    bin_locations = pd.DataFrame({

        "Bin_ID": [
            "BIN-001",
            "BIN-004",
            "BIN-002",
            "BIN-006"
        ],

        "Location": [
            "Main Gate",
            "Hostel",
            "Cafeteria",
            "Admin Block"
        ],

        "latitude": [
            28.4745,
            28.4755,
            28.4738,
            28.4762
        ],

        "longitude": [
            77.5030,
            77.5045,
            77.5025,
            77.5055
        ]
    })


    # ---------------- Calculations ----------------

    total_stops = len(route)

    high_priority = len(
        route[route["Priority"] == "High"]
    )

    route_distance = route["Distance_km"].max()

    estimated_time = "35 min"


    # ---------------- KPI Cards ----------------

    c1, c2, c3, c4 = st.columns(4)


    with c1:

        st.markdown(
            f"""
            <div class="card">
                <div class="card-icon">📍</div>
                <div class="card-title">Total Stops</div>
                <div class="card-value">{total_stops}</div>
                <div class="card-sub">Today's collection</div>
            </div>
            """,
            unsafe_allow_html=True
        )


    with c2:

        st.markdown(
            f"""
            <div class="card">
                <div class="card-icon">🔴</div>
                <div class="card-title">High Priority</div>
                <div class="card-value">{high_priority}</div>
                <div class="card-sub">Urgent bins</div>
            </div>
            """,
            unsafe_allow_html=True
        )


    with c3:

        st.markdown(
            f"""
            <div class="card">
                <div class="card-icon">🛣️</div>
                <div class="card-title">Route Distance</div>
                <div class="card-value">{route_distance} km</div>
                <div class="card-sub">Optimized route</div>
            </div>
            """,
            unsafe_allow_html=True
        )


    with c4:

        st.markdown(
            f"""
            <div class="card">
                <div class="card-icon">⏱️</div>
                <div class="card-title">Estimated Time</div>
                <div class="card-value">{estimated_time}</div>
                <div class="card-sub">Approx. collection time</div>
            </div>
            """,
            unsafe_allow_html=True
        )


    # ---------------- Route Overview ----------------

    st.subheader("📍 Route Overview")

    st.info(
        "🤖 AI has prioritized the collection sequence based on bin fill level and collection urgency."
    )


    # ---------------- Map ----------------
# ---------------- Map ----------------

    st.subheader("🗺️ Bin Locations & AI Collection Route")
    st.caption("Demo coordinates are used for now. Real bin locations can be added later.")

# Match bins with AI collection sequence
    route_map = route.merge(
        bin_locations,
        on=["Bin_ID", "Location"],
        how="left"
    )

    # Route line
    route_line = [
        [row["longitude"], row["latitude"]]
        for _, row in route_map.iterrows()
    ]

# Bin points
    bin_layer = pdk.Layer(
        "ScatterplotLayer",
        data=route_map,
        get_position="[longitude, latitude]",
        get_radius=35,
        get_fill_color=[37, 99, 235, 220],
        pickable=True,
    )

# Collection route
    route_layer = pdk.Layer(
        "PathLayer",
        data=[{"path": route_line}],
        get_path="path",
        get_width=6,
        get_color=[14, 116, 144],
    )

# Map
    view_state = pdk.ViewState(
        latitude=route_map["latitude"].mean(),
        longitude=route_map["longitude"].mean(),
        zoom=15,
        pitch=0
    )

    deck = pdk.Deck(
        layers=[
            route_layer,
            bin_layer
        ],
        initial_view_state=view_state,
        tooltip={
            "html": "<b>Bin:</b> {Bin_ID}<br>"
                    "<b>Location:</b> {Location}<br>"
                    "<b>Priority:</b> {Priority}",
            "style": {
                "backgroundColor": "white",
                "color": "black"
            }
        }
    )

    st.pydeck_chart(
        deck,
        use_container_width=True
    )

    st.markdown("### 🚛 AI Collection Path")

    st.write(
        "  →  ".join(route["Bin_ID"].tolist())
    )
   
    # ---------------- Route Table ----------------

    st.subheader("📋 Optimized Route")


    display_route = route.copy()

    display_route["Distance_km"] = (
        display_route["Distance_km"].astype(str)
        + " km"
    )


    st.dataframe(
        display_route,
        use_container_width=True,
        hide_index=True
    )


    # ---------------- Route System Status ----------------

    st.subheader("⚙️ Route System Status")


    s1, s2, s3 = st.columns(3)


    with s1:

        st.success(
            "✅ Route Optimized"
        )


    with s2:

        st.success(
            "✅ All Stops Connected"
        )


    with s3:

        st.success(
            "✅ Navigation Ready"
        )