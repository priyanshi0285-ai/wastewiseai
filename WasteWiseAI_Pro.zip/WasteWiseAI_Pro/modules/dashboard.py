import streamlit as st
import pandas as pd
import plotly.express as px
import os

def dashboard_page():

    # ---------------- CSS ----------------

    st.markdown("""
    <style>
    .main{
        background:#F5F7FA;
    }
    .title{
        font-size:42px;
        font-weight:800;
        color:#111827;
    }
    .subtitle{
        font-size:18px;
        color:#64748B;
        margin-bottom:25px;
    }
    .card{
        background:white;
        padding:15px;
        border-radius:18px;
        text-align:center;
        box-shadow:0px 4px 12px rgba(0,0,0,0.12);
        min-height:145px;
        display:flex;
        flex-direction:column;
        justify-content:center;
    }
    .card-icon{
        font-size:24px;
        margin-bottom:5px;
    }
    .card-title{
        font-size:16px;
        font-weight:600;
        color:#1E293B;
    }
    .card-value{
        font-size:34px;
        font-weight:800;
        color:#16A34A;
        margin:6px 0;
    }
    .card-sub{
        font-size:13px;
        color:#64748B;
    }
    </style>
    """, unsafe_allow_html=True)

    # ---------------- Load Sensor Data ----------------

    sensor_file = "database/sensor_data.csv"
    if os.path.exists(sensor_file):
        bin_data = pd.read_csv(sensor_file)

    else:
        bin_data = pd.DataFrame({
            "Bin_ID":["BIN-001"],
            "Location":["Main Gate"],
            "Fill_Level":[0],
            "Status":["Normal"]
        })

    # ---------------- Dashboard Calculations ----------------

    total_bins = len(bin_data)
    full_bins = len(
        bin_data[
            bin_data["Fill_Level"] >= 80
        ]
    )

    pickup_required = full_bins
    avg_fill = round(
        bin_data["Fill_Level"].mean(),
        1
    )

    # ---------------- Header ----------------

    st.markdown(
        "<div class='title'>♻️ WasteWiseAI Dashboard</div>",
        unsafe_allow_html=True
    )
    st.markdown(
        "<div class='subtitle'>Monitor and manage smart waste collection in real time.</div>",
        unsafe_allow_html=True
    )

    # ---------------- KPI Cards ----------------

    c1, c2, c3, c4 = st.columns(4)
    cards = [
        (
            "🗑️",
            "Total Bins",
            total_bins,
            "Installed Smart Bins"
        ),
        (
            "🚛",
            "Pickup Required",
            pickup_required,
            "Needs Collection"
        ),
        (
            "⚠️",
            "Full Bins",
            full_bins,
            "Above 80% Capacity"
        ),
        (
            "📊",
            "Average Fill",
            f"{avg_fill}%",
            "Across All Bins"
        )
    ]

    for col, data in zip(
        [c1, c2, c3, c4],
        cards
    ):
        with col:
            st.markdown(f"""
            <div class="card">
                <div class="card-icon">
                {data[0]}
                </div>
                <div class="card-title">
                {data[1]}
                </div>
                <div class="card-value">
                {data[2]}
                </div>
                <div class="card-sub">
                {data[3]}
                </div>
            </div>
            """, unsafe_allow_html=True)
    st.write("")
# ---------------- Charts ----------------

    left, right = st.columns([2, 1])
    with left:
        st.subheader("📊 Smart Bin Fill Levels")
        chart_data = bin_data.copy()
        chart_data = chart_data.sort_values(
            by="Fill_Level",
            ascending=False
        )
        fig = px.bar(
            chart_data,
            x="Bin_ID",
            y="Fill_Level",
            color="Status",
            text="Fill_Level",
            template="plotly_white",
            color_discrete_map={
                "Normal": "#22C55E",
                "Warning": "#F59E0B",
                "Full": "#EF4444"
            }
        )

        fig.update_layout(
            height=320,
            xaxis_title="Smart Bin",
            yaxis_title="Fill Level (%)",
            margin=dict(l=20, r=20, t=30, b=20),
            legend_title="Status"
        )

        fig.update_traces(
            texttemplate="%{text}%",
            textposition="outside"
        )

        st.plotly_chart(
            fig,
            use_container_width=True
        )


    with right:

        st.subheader("📍 Bin Status Distribution")

        status_count = (
            bin_data["Status"]
            .value_counts()
            .reset_index()
        )

        status_count.columns = [
            "Status",
            "Count"
        ]

        pie = px.pie(
            status_count,
            names="Status",
            values="Count",
            hole=0.45,
            template="plotly_white",
            color="Status",
            color_discrete_map={
                "Normal": "#22C55E",
                "Warning": "#F59E0B",
                "Full": "#EF4444"
            }
        )

        pie.update_layout(
            height=350,
            margin=dict(l=20, r=20, t=30, b=20)
        )
        legend=dict(
            orientation="h",
            y=-0.15,
            x=0.2
            )

        st.plotly_chart(
            pie,
            use_container_width=True
        )


# ---------------- Smart Bin Status ----------------

    st.subheader("🗑️ Smart Bin Status")
    display_data = bin_data.copy()
    display_data["Fill_Level"] = (
        display_data["Fill_Level"].astype(str) + "%"
    )
    st.dataframe(
        display_data,
        use_container_width=True,
        hide_index=True
    )

    st.write("")  
    # ---------------- System Overview ----------------

    st.subheader("🌱 System Overview")

    avg_fill = round(
        bin_data["Fill_Level"].mean(),
        1
    )

    normal_bins = len(
        bin_data[
            bin_data["Status"] == "Normal"
        ]
    )

    warning_bins = len(
        bin_data[
            bin_data["Status"] == "Warning"
        ]
    )

    full_bins = len(
        bin_data[
            bin_data["Status"] == "Full"
        ]
    )

    col1, col2, col3, col4 = st.columns(4)

    with col1:
        st.metric(
            "🗑️ Total Bins",
            total_bins
        )

    with col2:
        st.metric(
            "🟢 Normal",
            normal_bins
        )

    with col3:
        st.metric(
            "🟡 Warning",
            warning_bins
        )

    with col4:
        st.metric(
            "🔴 Full",
            full_bins
        )

    st.write("")

    st.markdown("### ⚙️ System Status")

    c1, c2, c3 = st.columns(3)

    with c1:
        st.success("✅ Smart Bins Connected")

    with c2:
        st.success("✅ Database Connected")

    with c3:
        st.success("✅ Monitoring Active")