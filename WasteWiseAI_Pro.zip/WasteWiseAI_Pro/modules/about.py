import streamlit as st


def about_page():

    st.title("♻️ About WasteWiseAI")

    st.write(
        "AI-powered smart waste management for a cleaner and more sustainable future."
    )

    # ---------------- CSS ----------------

    st.markdown("""
    <style>

    .about-title {
        color: #166534;
        font-size: 25px;
        font-weight: 700;
        margin-bottom: 15px;
    }

    .about-footer {
        text-align: center;
        color: #166534;
        font-size: 18px;
        font-weight: 600;
        padding: 30px;
    }

    </style>
    """, unsafe_allow_html=True)


    # =====================================================
    # 1. WHAT IS WASTEWISEAI?
    # =====================================================

    col1, col2 = st.columns([1.1, 0.9], gap="large")

    with col1:

        st.markdown(
            '<div class="about-title">🌱 What is WasteWiseAI?</div>',
            unsafe_allow_html=True
        )

        st.write("""
        WasteWiseAI is an AI-powered smart waste management system
        designed to improve the way waste is segregated, collected,
        and monitored. By combining artificial intelligence with
        data analytics, the system aims to make waste management
        more organized, efficient, and sustainable.
        """)

        st.write("""
        The idea is simple: use technology to understand waste better,
        monitor waste collection more intelligently, and provide useful
        information that can support better waste-management decisions.
        """)

    with col2:

        st.image(
            "assets/about/smart_waste.jpeg",
            width=350
        )


    # =====================================================
    # 2. PROBLEM STATEMENT
    # =====================================================

    col1, col2 = st.columns([0.9, 1.1], gap="large")

    with col1:

        st.image(
            "assets/about/ai_solution.jpeg",
            width=350
        )

    with col2:

        st.markdown(
            '<div class="about-title">🎯 The Problem We Wanted to Solve</div>',
            unsafe_allow_html=True
        )

        st.write("""
        Traditional waste management faces several challenges that
        make the process less efficient and less sustainable. Poor
        waste segregation can make recycling difficult, while
        overflowing bins can create unhygienic surroundings.
        """)

        st.write("""
        At the same time, inefficient collection routes, low recycling
        rates, and high operational costs make waste management more
        challenging for communities and organizations.
        """)


    # =====================================================
    # 3. OUR SOLUTION
    # =====================================================

    col1, col2 = st.columns([1.1, 0.9], gap="large")

    with col1:

        st.markdown(
            '<div class="about-title">💡 Our Solution</div>',
            unsafe_allow_html=True
        )

        st.write("""
        WasteWiseAI addresses these challenges by bringing artificial
        intelligence and data analytics into waste management. The
        system uses AI-based waste classification to support better
        segregation and smart bin monitoring to track bin conditions.
        """)

        st.write("""
        Collection scheduling helps organize pickups, while route
        optimization helps plan more efficient collection journeys.
        Waste analytics and reporting then turn collected information
        into useful insights for better decision-making.
        """)

    with col2:

        st.image(
            "assets/about/collection.jpeg",
            width=350
        )


    # =====================================================
    # 4. KEY FEATURES
    # =====================================================

    col1, col2 = st.columns([0.9, 1.1], gap="large")

    with col1:

        st.image(
            "assets/about/sustainability.jpeg",
            width=350
        )

    with col2:

        st.markdown(
            '<div class="about-title">✨ Key Features</div>',
            unsafe_allow_html=True
        )

        st.write("""
        WasteWiseAI brings several functions together in one platform.
        AI Waste Detection helps identify waste categories from images,
        while Smart Bin Monitoring provides an overview of bin conditions.
        """)

        st.write("""
        The system also supports Route Optimization and Waste Collection
        Management to make collection activities more organized. Reports
        and Dashboard features provide a clear view of waste-related data,
        while Sustainability Analytics helps understand the broader
        environmental impact.
        """)


    # =====================================================
    # 5. TECHNOLOGY
    # =====================================================

    st.markdown("---")

    st.markdown(
        '<div class="about-title">🛠️ The Technology Behind WasteWiseAI</div>',
        unsafe_allow_html=True
    )

    st.write("""
    WasteWiseAI combines several technologies to bring the complete
    system together. Python provides the core programming environment,
    while Streamlit powers the interactive application interface.
    TensorFlow supports AI-based waste classification.
    """)

    st.write("""
    Pandas is used for data handling, Plotly creates interactive
    visualizations, and OpenCV provides image-processing support.
    Together, these technologies transform waste images and operational
    data into a simple, interactive, and intelligent waste-management
    platform.
    """)


    # =====================================================
    # 6. SUSTAINABLE DEVELOPMENT GOALS
    # =====================================================

    st.markdown("---")

    st.markdown(
        '<div class="about-title">🌍 Sustainable Development Goals</div>',
        unsafe_allow_html=True
    )

    st.write("""
    WasteWiseAI is designed with sustainability in mind and connects
    with three important United Nations Sustainable Development Goals.
    """)

    st.write("""
    **SDG 11 – Sustainable Cities and Communities:** supporting cleaner,
    smarter, and more efficient communities.
    """)

    st.write("""
    **SDG 12 – Responsible Consumption and Production:** encouraging
    better waste segregation, recycling, and responsible waste handling.
    """)

    st.write("""
    **SDG 13 – Climate Action:** supporting more efficient and
    sustainable waste-management practices that can contribute to
    environmental improvement.
    """)


    # =====================================================
    # FOOTER
    # =====================================================

    st.markdown(
        '<div class="about-footer">'
        '🌱 WasteWiseAI — Turning smarter technology into a cleaner tomorrow.'
        '</div>',
        unsafe_allow_html=True
    )