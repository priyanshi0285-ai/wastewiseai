import streamlit as st
from config import *
from PIL import Image
# Import modules
from modules.dashboard import dashboard_page
from modules.smart_bins import smart_bins_page
from modules.collection import collection_page
from modules.route import route_page
from modules.reports import reports_page
from modules.profile import profile_page
from modules.about import about_page


# ---------------- Page Configuration ---------------- #

st.set_page_config(
    page_title=PAGE_TITLE,
    page_icon=PAGE_ICON,
    layout=LAYOUT,
    initial_sidebar_state="expanded"
)
# ---------------- Sidebar ---------------- #
# ---------------- Sidebar ---------------- #

st.markdown("""
<style>

/* Sidebar background */
[data-testid="stSidebar"]{
    background-color:#0F172A;
}

/* Logo */
[data-testid="stSidebar"] [data-testid="stImage"]{
    display:flex;
    justify-content:center;
    margin-bottom:-20px;
}

[data-testid="stSidebar"] [data-testid="stImage"] img{
    margin:auto;
}

/* All sidebar text */
[data-testid="stSidebar"] p,
[data-testid="stSidebar"] span,
[data-testid="stSidebar"] label,
[data-testid="stSidebar"] h3{
    color:white !important;
}

/* Hide radio heading */
[data-testid="stSidebar"] .stRadio > label{
    display:none;
}

/* Remove radio circle */
div[role="radiogroup"] label > div:first-child{
    display:none !important;
}

/* Menu text alignment */
div[role="radiogroup"] label{
    color:white !important;
    border-radius:10px;
    padding:10px 12px;
    margin-bottom:5px;
    font-weight:500;
}

/* Hover */
div[role="radiogroup"] label:hover{
    background:#1E293B;
}

/* Version */
[data-testid="stSidebar"] .stCaption{
    color:#94A3B8 !important;
}

</style>
""", unsafe_allow_html=True)

logo = Image.open("assets/logo.png")

with st.sidebar:

    st.image(logo, width=100)

    st.markdown(
        "<h3 style='text-align:center;'>WasteWiseAI Pro</h3>",
        unsafe_allow_html=True
    )

    st.markdown(
        "<p style='text-align:center;color:#94A3B8;'>Smart Waste Management System</p>",
        unsafe_allow_html=True
    )

    page = st.radio(
        "",
        [
            "🏠 Dashboard",
            "🗑 Smart Bins",
            "🚛 Collection",
            "🗺 Route",
            "📊 Reports",
            "👤 Login / Register",
            "ℹ About"
        ]
    )

    st.divider()
    st.caption(f"Version {VERSION}")
  
# ---------------- Navigation ---------------- #

if page == "🏠 Dashboard":
    dashboard_page()

elif page == "🗑 Smart Bins":
     smart_bins_page()

elif page == "🚛 Collection":
    collection_page()

elif page == "🗺 Route":
    route_page()

elif page == "📊 Reports":
    reports_page()

elif page == "👤 Login / Register":
    profile_page()

elif page == "ℹ About":
   about_page()